using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace PyarisApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            var products = new List<object>
            {
                new { id = 1, name = "Chocolate Cake", price = 799, image = "/images/productimages/chocolate.jpg" },
                new { id = 2, name = "Black Forest", price = 899, image = "/images/productimages/black_forest.jpg" },
                new { id = 3, name = "Vanilla Cake", price = 699, image = "/images/productimages/vanilla.jpg" }
            };

            return Ok(products);
        }
    }
}
