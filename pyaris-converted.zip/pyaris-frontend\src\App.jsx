import React, {useEffect, useState} from 'react'

export default function App(){
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const apiBase = 'http://localhost:5000'

  useEffect(()=>{
    fetch(apiBase + '/api/products')
      .then(r=>r.json())
      .then(data=>{
        setProducts(data)
      })
      .catch(err=>console.error(err))
      .finally(()=>setLoading(false))
  },[])

  return (
    <div className="container">
      <header>
        <h1>Paris Bakery (React + ASP.NET Core)</h1>
      </header>

      <main>
        <section>
          <h2>Products</h2>
          {loading && <div>Loading...</div>}
          {!loading && products.length === 0 && <div>No products found.</div>}
          <div className="grid">
            {products.map(p=> (
              <div className="card" key={p.id}>
                <img src={p.image} alt={p.name} />
                <div className="card-body">
                  <div className="title">{p.name}</div>
                  <div className="price">₹{p.price}</div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

      <footer>
        <small>Converted demo — replace with full UI from your ASPX pages.</small>
      </footer>
    </div>
  )
}
