Converted Pyaris Bakery (partial)

This workspace contains a scaffolded conversion of the original ASPX site into:

- `PyarisApi/` - an ASP.NET Core Web API (net6.0) with a sample `ProductsController` returning demo product data.
- `pyaris-frontend/` - a Vite + React (JavaScript) frontend that fetches products from `http://localhost:5000/api/products`.

Notes
- This is an initial automated scaffold and demo conversion (MVP). The original ASPX pages, server-side logic, and payment integrations must be migrated manually into the new API and React components.

Quick start (Windows, PowerShell):

1. Build & run the backend API

```powershell
cd "e:\New folder\pyaris-bakery\PyarisApi"
# run the API
dotnet run
```

By default the API will bind to a local port (check the console output; it may be `http://localhost:5000` or another port).

2. Run the frontend dev server

```powershell
cd "e:\New folder\pyaris-bakery\pyaris-frontend"
npm install
npm run dev
```

3. Open the frontend in the browser (Vite opens `http://localhost:5173` by default). The frontend expects the API to be available at `http://localhost:5000`.

Next steps to complete full migration:
- Port database access and business logic from ASP.NET Framework code-behind to EF Core or ADO.NET in the API.
- Recreate full UI in React components using markup from the ASPX pages and `Pyaris.master` layout.
- Implement authentication, payment integrations, and file/image storage.
- Add environment configuration and secure storage for secrets (do NOT commit credentials).

If you want, I can continue migrating specific pages (home, products, cart, checkout) next — tell me which pages to prioritize.
