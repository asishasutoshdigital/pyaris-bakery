# Pyaris Bakery - Frontend

Vite + React (JavaScript) demo frontend for the converted project. It fetches products from `http://localhost:5000/api/products` by default.

Commands:

```bash
# install deps
npm install

# dev server
npm run dev

# build
npm run build

# preview build
npm run preview
```
